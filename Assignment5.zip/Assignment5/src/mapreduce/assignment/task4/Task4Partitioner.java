package mapreduce.assignment.task4;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class Task4Partitioner extends Partitioner<Text, IntWritable> {

	@Override
	public int getPartition(Text key, IntWritable value, int numPartitions) {
			String word = key.toString();
			char letter = word.toLowerCase().charAt(0);
			int partitionNumber = 0;
			
			switch(letter) {
			case 'a': 
			case 'b': 
			case 'c': 
			case 'd': 
			case 'e': 
			case 'f': partitionNumber = 0;  break;
			case 'g': 
			case 'h': 
			case 'i': 
			case 'j': 
			case 'k': 
			case 'l': partitionNumber = 1;  break;
			case 'm': 
			case 'n': 
			case 'o': 
			case 'p': 
			case 'q': 
			case 'r': partitionNumber = 2;  break;
			default: partitionNumber = 3;  break;
			}
			return partitionNumber;
	}
}